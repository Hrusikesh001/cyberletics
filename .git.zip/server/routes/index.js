module.exports = {
  auth: require('./auth'),
  // Add other routes here as needed
}; 